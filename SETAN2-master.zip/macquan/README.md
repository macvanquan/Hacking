# recode?
# silahkan kalo bisa
```
install
pkg install git
pkg inatall python2
pip install requests
pip install mechanize
git clone https://github.com/pashayogi/SETAN2
cd SETAN2
python2 SETAN2.py
```